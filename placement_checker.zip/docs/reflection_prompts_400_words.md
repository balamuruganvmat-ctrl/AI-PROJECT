# 400-word reflection: prompts only

This must be in your own voice, about your own experience. Cover:
1. Which part was hardest and what you did when stuck.
2. One moment the AI was wrong or the LLM misbehaved, and how your checks handled it.
3. Why student data stays in Python, in your own words.
4. What you would change with another two weeks.
5. Three learnings for the presentation.
