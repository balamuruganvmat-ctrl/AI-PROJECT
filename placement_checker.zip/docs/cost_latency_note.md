# Cost and latency note

> The token counts below are estimates for this design. **The prices are placeholders: put in your provider's real prices.** On a free-tier key the cost is zero, but check the rate limit.

## Calls per day
- One API call per post, and student data is never sent.
- The placement cell gets "several posts a week". Assume a busy day of **10 posts**.
- Best case: 10 calls. Worst case, if every reply fails once and is retried: **20 calls**.

## Latency
- One short call (about 800 tokens in, under 100 out) typically takes **1 to 3 seconds**.
- 10 posts, one after another: roughly **10 to 30 seconds**. Worst case with retries: about a minute.
- Matching and writing files take well under a second.

## Cost per day (formula)
`cost = calls × (input_tokens × input_price + output_tokens × output_price)`

Estimates per call: system prompt about 700 tokens + post about 60 = **about 800 input tokens**; JSON reply about **80 output tokens**.

Illustrative prices (replace them): $1 per million input tokens, $5 per million output tokens.

| Scenario | Calls | Input tokens | Output tokens | Cost |
|---|---|---|---|---|
| Normal day | 10 | 8,000 | 800 | about $0.012 |
| Worst case (all retried) | 20 | 16,000 | 1,600 | about $0.024 |

Even the worst case is a few cents a day, so the real constraint is correctness, not cost.
